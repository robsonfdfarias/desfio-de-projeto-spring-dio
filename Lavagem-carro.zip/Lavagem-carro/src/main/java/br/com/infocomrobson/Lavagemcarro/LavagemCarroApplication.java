package br.com.infocomrobson.Lavagemcarro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LavagemCarroApplication {

	public static void main(String[] args) {
		SpringApplication.run(LavagemCarroApplication.class, args);
	}

}
